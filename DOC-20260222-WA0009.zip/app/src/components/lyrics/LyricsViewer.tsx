// =====================================================
// RaPut4 Music - Lyrics Viewer with Auto-Sync
// =====================================================

import { useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { X, Music } from 'lucide-react';
import type { LyricLine } from '@/types';

interface LyricsViewerProps {
  lyrics: LyricLine[];
  currentIndex: number;
  onClose: () => void;
  songTitle: string;
  artistName?: string;
}

export function LyricsViewer({
  lyrics,
  currentIndex,
  onClose,
  songTitle,
  artistName
}: LyricsViewerProps) {
  const lyricsRef = useRef<HTMLDivElement>(null);
  const activeLineRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to active lyric
  useEffect(() => {
    if (activeLineRef.current && lyricsRef.current) {
      activeLineRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });
    }
  }, [currentIndex]);

  // Close on escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, [onClose]);

  if (lyrics.length === 0) {
    return (
      <div className="fixed inset-0 z-[60] bg-background/95 backdrop-blur-lg flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div>
            <h3 className="font-semibold">{songTitle}</h3>
            <p className="text-sm text-muted-foreground">{artistName}</p>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>
        
        {/* Empty State */}
        <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground">
          <Music className="w-16 h-16 mb-4 opacity-50" />
          <p className="text-lg">No lyrics available for this song</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[60] bg-background/95 backdrop-blur-lg flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border glass">
        <div>
          <h3 className="font-semibold">{songTitle}</h3>
          <p className="text-sm text-muted-foreground">{artistName}</p>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="w-5 h-5" />
        </Button>
      </div>

      {/* Lyrics Content */}
      <div
        ref={lyricsRef}
        className="flex-1 overflow-y-auto lyrics-container p-6 sm:p-8"
      >
        <div className="max-w-2xl mx-auto space-y-4">
          {lyrics.map((line, index) => (
            <div
              key={index}
              ref={index === currentIndex ? activeLineRef : null}
              className={`text-center transition-all duration-300 ${
                index === currentIndex
                  ? 'text-2xl sm:text-3xl font-bold text-primary scale-105 text-glow-purple'
                  : index < currentIndex
                  ? 'text-lg text-muted-foreground/60'
                  : 'text-lg text-muted-foreground'
              }`}
            >
              {line.text}
            </div>
          ))}
        </div>
      </div>

      {/* Footer Info */}
      <div className="p-4 border-t border-border glass text-center text-sm text-muted-foreground">
        Press ESC to close lyrics view
      </div>
    </div>
  );
}
