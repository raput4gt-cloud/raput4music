// =====================================================
// RaPut4 Music - Song Card Component
// =====================================================

import { useState } from 'react';
import { usePlayer } from '@/contexts/PlayerContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Play,
  Pause,
  Heart,
  MoreVertical,
  ListMusic,
  Trash2,
  Edit,
  Plus,
  Check
} from 'lucide-react';
import type { Song, Playlist } from '@/types';
import { likeSong, unlikeSong, addSongToPlaylist, fetchPlaylists } from '@/lib/supabase';
import { toast } from 'sonner';

interface SongCardProps {
  song: Song;
  variant?: 'default' | 'compact' | 'list';
  showActions?: boolean;
  onEdit?: (song: Song) => void;
  onDelete?: (song: Song) => void;
  playlists?: Playlist[];
}

export function SongCard({
  song,
  variant = 'default',
  showActions = true,
  onEdit,
  onDelete,
  playlists: initialPlaylists
}: SongCardProps) {
  const { currentSong, isPlaying, playSong, togglePlay } = usePlayer();
  const { user } = useAuth();
  const [isLiked, setIsLiked] = useState(song.is_liked || false);
  const [likeCount, setLikeCount] = useState(song.like_count || 0);
  const [playlists, setPlaylists] = useState<Playlist[]>(initialPlaylists || []);
  const [addedPlaylists, setAddedPlaylists] = useState<Set<string>>(new Set());

  const isCurrentSong = currentSong?.id === song.id;
  const isCurrentlyPlaying = isCurrentSong && isPlaying;

  // Load playlists if not provided
  const loadPlaylists = async () => {
    if (!user) return;
    if (playlists.length === 0) {
      const { data } = await fetchPlaylists(user.id);
      if (data) {
        setPlaylists(data);
      }
    }
  };

  // Handle play
  const handlePlay = () => {
    if (isCurrentSong) {
      togglePlay();
    } else {
      playSong(song);
    }
  };

  // Handle like
  const handleLike = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) {
      toast.error('Please sign in to like songs');
      return;
    }

    try {
      if (isLiked) {
        await unlikeSong(user.id, song.id);
        setIsLiked(false);
        setLikeCount(prev => prev - 1);
      } else {
        await likeSong(user.id, song.id);
        setIsLiked(true);
        setLikeCount(prev => prev + 1);
        toast.success('Added to liked songs');
      }
    } catch (error) {
      toast.error('Failed to update like status');
    }
  };

  // Handle add to playlist
  const handleAddToPlaylist = async (playlistId: string) => {
    try {
      await addSongToPlaylist(playlistId, song.id);
      setAddedPlaylists(prev => new Set(prev).add(playlistId));
      toast.success('Added to playlist');
    } catch (error) {
      toast.error('Failed to add to playlist');
    }
  };

  // Compact variant
  if (variant === 'compact') {
    return (
      <div
        className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted transition-colors group cursor-pointer"
        onClick={handlePlay}
      >
        <div className="relative w-12 h-12 rounded-lg overflow-hidden flex-shrink-0 bg-muted">
          {song.cover_url ? (
            <img src={song.cover_url} alt={song.title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-primary/10">
              <ListMusic className="w-5 h-5 text-primary" />
            </div>
          )}
          <div className={`absolute inset-0 bg-black/50 flex items-center justify-center transition-opacity ${
            isCurrentlyPlaying ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
          }`}>
            {isCurrentlyPlaying ? (
              <div className="flex items-center gap-0.5">
                <div className="w-1 h-3 bg-white rounded-full sound-bar" />
                <div className="w-1 h-4 bg-white rounded-full sound-bar" />
                <div className="w-1 h-2 bg-white rounded-full sound-bar" />
              </div>
            ) : (
              <Play className="w-5 h-5 text-white" />
            )}
          </div>
        </div>
        
        <div className="flex-1 min-w-0">
          <h4 className={`font-medium text-sm truncate ${isCurrentSong ? 'text-primary' : ''}`}>
            {song.title}
          </h4>
          <p className="text-xs text-muted-foreground truncate">
            {song.artist?.name || 'Unknown Artist'}
          </p>
        </div>

        {showActions && (
          <Button
            variant="ghost"
            size="icon"
            className={`opacity-0 group-hover:opacity-100 transition-opacity ${isLiked ? 'text-red-500 opacity-100' : ''}`}
            onClick={handleLike}
          >
            <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
          </Button>
        )}
      </div>
    );
  }

  // List variant
  if (variant === 'list') {
    return (
      <div
        className="flex items-center gap-4 p-3 rounded-lg hover:bg-muted transition-colors group cursor-pointer"
        onClick={handlePlay}
      >
        <div className="relative w-10 h-10 rounded-lg overflow-hidden flex-shrink-0 bg-muted">
          {song.cover_url ? (
            <img src={song.cover_url} alt={song.title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-primary/10">
              <ListMusic className="w-4 h-4 text-primary" />
            </div>
          )}
        </div>
        
        <div className="flex-1 min-w-0">
          <h4 className={`font-medium truncate ${isCurrentSong ? 'text-primary' : ''}`}>
            {song.title}
          </h4>
          <p className="text-sm text-muted-foreground truncate">
            {song.artist?.name || 'Unknown Artist'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {showActions && (
            <Button
              variant="ghost"
              size="icon"
              className={isLiked ? 'text-red-500' : ''}
              onClick={handleLike}
            >
              <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
            </Button>
          )}
          
          {showActions && user && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                <Button variant="ghost" size="icon">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={(e) => {
                  e.stopPropagation();
                  onEdit?.(song);
                }}>
                  <Edit className="w-4 h-4 mr-2" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem onClick={(e) => {
                  e.stopPropagation();
                  onDelete?.(song);
                }} className="text-destructive">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>
    );
  }

  // Default card variant
  return (
    <div className="group relative bg-card rounded-xl overflow-hidden border border-border hover:border-primary/50 transition-all hover:shadow-lg hover:shadow-primary/10">
      {/* Cover Image */}
      <div
        className="relative aspect-square overflow-hidden cursor-pointer"
        onClick={handlePlay}
      >
        {song.cover_url ? (
          <img
            src={song.cover_url}
            alt={song.title}
            className="w-full h-full object-cover transition-transform group-hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-accent/20">
            <ListMusic className="w-16 h-16 text-primary/50" />
          </div>
        )}
        
        {/* Play Overlay */}
        <div className={`absolute inset-0 bg-black/50 flex items-center justify-center transition-opacity ${
          isCurrentlyPlaying ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
        }`}>
          <Button
            size="icon"
            className="w-14 h-14 rounded-full gradient-purple text-white"
          >
            {isCurrentlyPlaying ? (
              <Pause className="w-6 h-6" />
            ) : (
              <Play className="w-6 h-6 ml-1" />
            )}
          </Button>
        </div>

        {/* Like Button */}
        {showActions && (
          <Button
            variant="ghost"
            size="icon"
            className={`absolute top-2 right-2 bg-black/50 hover:bg-black/70 text-white opacity-0 group-hover:opacity-100 transition-opacity ${
              isLiked ? 'opacity-100 text-red-500' : ''
            }`}
            onClick={handleLike}
          >
            <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
          </Button>
        )}
      </div>

      {/* Info */}
      <div className="p-4">
        <h3
          className={`font-semibold truncate cursor-pointer hover:text-primary transition-colors ${
            isCurrentSong ? 'text-primary' : ''
          }`}
          onClick={handlePlay}
        >
          {song.title}
        </h3>
        <p className="text-sm text-muted-foreground truncate mt-1">
          {song.artist?.name || 'Unknown Artist'}
        </p>
        
        <div className="flex items-center justify-between mt-3">
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Heart className="w-3 h-3" />
            <span>{likeCount}</span>
          </div>
          
          {showActions && user && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={(e) => {
                  e.stopPropagation();
                  loadPlaylists();
                }}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add to Playlist
                </DropdownMenuItem>
                {playlists.map(playlist => (
                  <DropdownMenuItem
                    key={playlist.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleAddToPlaylist(playlist.id);
                    }}
                    disabled={addedPlaylists.has(playlist.id)}
                  >
                    {addedPlaylists.has(playlist.id) ? (
                      <Check className="w-4 h-4 mr-2" />
                    ) : (
                      <ListMusic className="w-4 h-4 mr-2" />
                    )}
                    {playlist.name}
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={(e) => {
                  e.stopPropagation();
                  onEdit?.(song);
                }}>
                  <Edit className="w-4 h-4 mr-2" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete?.(song);
                  }}
                  className="text-destructive"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>
    </div>
  );
}
