// =====================================================
// RaPut4 Music - Artist Card Component
// =====================================================

import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Users, User } from 'lucide-react';
import type { Artist } from '@/types';
import { followArtist, unfollowArtist } from '@/lib/supabase';
import { toast } from 'sonner';

interface ArtistCardProps {
  artist: Artist;
  onClick?: () => void;
}

export function ArtistCard({ artist, onClick }: ArtistCardProps) {
  const { user } = useAuth();
  const [isFollowing, setIsFollowing] = useState(artist.is_following || false);
  const [followerCount, setFollowerCount] = useState(artist.follower_count || 0);

  const handleFollow = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) {
      toast.error('Please sign in to follow artists');
      return;
    }

    try {
      if (isFollowing) {
        await unfollowArtist(user.id, artist.id);
        setIsFollowing(false);
        setFollowerCount(prev => prev - 1);
        toast.success(`Unfollowed ${artist.name}`);
      } else {
        await followArtist(user.id, artist.id);
        setIsFollowing(true);
        setFollowerCount(prev => prev + 1);
        toast.success(`Following ${artist.name}`);
      }
    } catch (error) {
      toast.error('Failed to update follow status');
    }
  };

  return (
    <div
      className="group relative bg-card rounded-xl overflow-hidden border border-border hover:border-primary/50 transition-all hover:shadow-lg hover:shadow-primary/10 cursor-pointer"
      onClick={onClick}
    >
      {/* Artist Image */}
      <div className="relative aspect-square overflow-hidden">
        {artist.image_url ? (
          <img
            src={artist.image_url}
            alt={artist.name}
            className="w-full h-full object-cover transition-transform group-hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-accent/20">
            <User className="w-20 h-20 text-primary/50" />
          </div>
        )}
        
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
      </div>

      {/* Info */}
      <div className="absolute bottom-0 left-0 right-0 p-4">
        <h3 className="font-semibold text-lg truncate group-hover:text-primary transition-colors">
          {artist.name}
        </h3>
        
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Users className="w-4 h-4" />
            <span>{followerCount.toLocaleString()} followers</span>
          </div>
          
          {user && (
            <Button
              size="sm"
              variant={isFollowing ? 'outline' : 'default'}
              className={isFollowing ? '' : 'gradient-purple text-white'}
              onClick={handleFollow}
            >
              {isFollowing ? 'Following' : 'Follow'}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

// Compact artist card for lists
export function ArtistCardCompact({ artist, onClick }: ArtistCardProps) {
  const { user } = useAuth();
  const [isFollowing, setIsFollowing] = useState(artist.is_following || false);

  const handleFollow = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) {
      toast.error('Please sign in to follow artists');
      return;
    }

    try {
      if (isFollowing) {
        await unfollowArtist(user.id, artist.id);
        setIsFollowing(false);
        toast.success(`Unfollowed ${artist.name}`);
      } else {
        await followArtist(user.id, artist.id);
        setIsFollowing(true);
        toast.success(`Following ${artist.name}`);
      }
    } catch (error) {
      toast.error('Failed to update follow status');
    }
  };

  return (
    <div
      className="flex items-center gap-4 p-3 rounded-lg hover:bg-muted transition-colors cursor-pointer"
      onClick={onClick}
    >
      <div className="w-14 h-14 rounded-full overflow-hidden flex-shrink-0 bg-muted">
        {artist.image_url ? (
          <img src={artist.image_url} alt={artist.name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-primary/10">
            <User className="w-6 h-6 text-primary" />
          </div>
        )}
      </div>
      
      <div className="flex-1 min-w-0">
        <h4 className="font-medium truncate">{artist.name}</h4>
        <p className="text-sm text-muted-foreground">
          {(artist.follower_count || 0).toLocaleString()} followers
        </p>
      </div>

      {user && (
        <Button
          size="sm"
          variant={isFollowing ? 'outline' : 'default'}
          className={isFollowing ? '' : 'gradient-purple text-white'}
          onClick={handleFollow}
        >
          {isFollowing ? 'Following' : 'Follow'}
        </Button>
      )}
    </div>
  );
}
