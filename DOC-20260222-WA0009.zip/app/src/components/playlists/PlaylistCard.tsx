// =====================================================
// RaPut4 Music - Playlist Card Component
// =====================================================

import { ListMusic, Play, MoreVertical, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import type { Playlist } from '@/types';
import { deletePlaylist } from '@/lib/supabase';
import { toast } from 'sonner';

interface PlaylistCardProps {
  playlist: Playlist;
  onClick?: () => void;
  onDelete?: () => void;
}

export function PlaylistCard({ playlist, onClick, onDelete }: PlaylistCardProps) {
  const handleDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Are you sure you want to delete this playlist?')) return;
    
    try {
      await deletePlaylist(playlist.id);
      toast.success('Playlist deleted');
      onDelete?.();
    } catch (error) {
      toast.error('Failed to delete playlist');
    }
  };

  return (
    <div
      className="group relative bg-card rounded-xl overflow-hidden border border-border hover:border-primary/50 transition-all hover:shadow-lg hover:shadow-primary/10 cursor-pointer"
      onClick={onClick}
    >
      {/* Cover Image */}
      <div className="relative aspect-square overflow-hidden">
        {playlist.cover_url ? (
          <img
            src={playlist.cover_url}
            alt={playlist.name}
            className="w-full h-full object-cover transition-transform group-hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-accent/20">
            <ListMusic className="w-16 h-16 text-primary/50" />
          </div>
        )}
        
        {/* Play Overlay */}
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <Button
            size="icon"
            className="w-14 h-14 rounded-full gradient-purple text-white"
          >
            <Play className="w-6 h-6 ml-1" />
          </Button>
        </div>

        {/* Menu Button */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-2 right-2 bg-black/50 hover:bg-black/70 text-white opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <MoreVertical className="w-5 h-5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={handleDelete} className="text-destructive">
              <Trash2 className="w-4 h-4 mr-2" />
              Delete Playlist
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Info */}
      <div className="p-4">
        <h3 className="font-semibold truncate group-hover:text-primary transition-colors">
          {playlist.name}
        </h3>
        <p className="text-sm text-muted-foreground mt-1">
          {playlist.song_count || 0} songs
        </p>
      </div>
    </div>
  );
}

// Compact playlist card for lists
export function PlaylistCardCompact({ playlist, onClick, onDelete }: PlaylistCardProps) {
  const handleDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Are you sure you want to delete this playlist?')) return;
    
    try {
      await deletePlaylist(playlist.id);
      toast.success('Playlist deleted');
      onDelete?.();
    } catch (error) {
      toast.error('Failed to delete playlist');
    }
  };

  return (
    <div
      className="flex items-center gap-4 p-3 rounded-lg hover:bg-muted transition-colors cursor-pointer"
      onClick={onClick}
    >
      <div className="w-14 h-14 rounded-lg overflow-hidden flex-shrink-0 bg-muted">
        {playlist.cover_url ? (
          <img src={playlist.cover_url} alt={playlist.name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-primary/10">
            <ListMusic className="w-6 h-6 text-primary" />
          </div>
        )}
      </div>
      
      <div className="flex-1 min-w-0">
        <h4 className="font-medium truncate">{playlist.name}</h4>
        <p className="text-sm text-muted-foreground">
          {playlist.song_count || 0} songs
        </p>
      </div>

      <DropdownMenu>
        <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
          <Button variant="ghost" size="icon">
            <MoreVertical className="w-4 h-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={handleDelete} className="text-destructive">
            <Trash2 className="w-4 h-4 mr-2" />
            Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
