// =====================================================
// RaPut4 Music - Global Music Player
// =====================================================

import { useState, useRef, useEffect } from 'react';
import { usePlayer } from '@/contexts/PlayerContext';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  ListMusic,
  Heart,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { LyricsViewer } from '@/components/lyrics/LyricsViewer';
import { useAuth } from '@/contexts/AuthContext';
import { likeSong, unlikeSong } from '@/lib/supabase';
import { toast } from 'sonner';

export function MusicPlayer() {
  const {
    currentSong,
    isPlaying,
    currentTime,
    duration,
    volume,
    togglePlay,
    seek,
    setVolume,
    playNext,
    playPrevious,
    queue,
    currentQueueIndex,
    lyrics,
    currentLyricIndex
  } = usePlayer();
  
  const { user } = useAuth();
  const [showLyrics, setShowLyrics] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  const progressRef = useRef<HTMLDivElement>(null);

  // Check if song is liked
  useEffect(() => {
    if (currentSong && user) {
      // Fetch like status
      const checkLikeStatus = async () => {
        const { data: likedSongs } = await import('@/lib/supabase').then(m => 
          m.supabase
            .from('liked_songs')
            .select('*')
            .eq('user_id', user.id)
            .eq('song_id', currentSong.id)
        );
        setIsLiked(likedSongs && likedSongs.length > 0);
      };
      checkLikeStatus();

      // Fetch like count
      const fetchLikeCount = async () => {
        const { count } = await import('@/lib/supabase').then(m => 
          m.supabase
            .from('liked_songs')
            .select('*', { count: 'exact', head: true })
            .eq('song_id', currentSong.id)
        );
        setLikeCount(count || 0);
      };
      fetchLikeCount();
    }
  }, [currentSong, user]);

  // Format time display
  const formatTime = (seconds: number) => {
    if (!seconds || isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Handle progress bar click
  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (progressRef.current && duration) {
      const rect = progressRef.current.getBoundingClientRect();
      const percent = (e.clientX - rect.left) / rect.width;
      seek(percent * duration);
    }
  };

  // Handle like/unlike
  const handleLikeToggle = async () => {
    if (!user) {
      toast.error('Please sign in to like songs');
      return;
    }
    if (!currentSong) return;

    try {
      if (isLiked) {
        await unlikeSong(user.id, currentSong.id);
        setIsLiked(false);
        setLikeCount(prev => prev - 1);
        toast.success('Removed from liked songs');
      } else {
        await likeSong(user.id, currentSong.id);
        setIsLiked(true);
        setLikeCount(prev => prev + 1);
        toast.success('Added to liked songs');
      }
    } catch (error) {
      toast.error('Failed to update like status');
    }
  };

  // Don't render if no song is selected
  if (!currentSong) return null;

  return (
    <>
      {/* Lyrics Panel */}
      {showLyrics && (
        <LyricsViewer
          lyrics={lyrics}
          currentIndex={currentLyricIndex}
          onClose={() => setShowLyrics(false)}
          songTitle={currentSong.title}
          artistName={currentSong.artist?.name}
        />
      )}

      {/* Main Player Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-50 glass border-t border-border">
        {/* Progress Bar */}
        <div
          ref={progressRef}
          className="h-1 bg-muted cursor-pointer group"
          onClick={handleProgressClick}
        >
          <div
            className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-100 relative"
            style={{ width: `${duration ? (currentTime / duration) * 100 : 0}%` }}
          >
            <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-primary rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-lg" />
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex items-center justify-between gap-4">
            {/* Song Info */}
            <div className="flex items-center gap-3 flex-1 min-w-0">
              <div className="relative w-14 h-14 rounded-lg overflow-hidden flex-shrink-0 bg-muted">
                {currentSong.cover_url ? (
                  <img
                    src={currentSong.cover_url}
                    alt={currentSong.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-primary/10">
                    <ListMusic className="w-6 h-6 text-primary" />
                  </div>
                )}
                {isPlaying && (
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center gap-0.5">
                    <div className="w-1 h-3 bg-white rounded-full sound-bar" />
                    <div className="w-1 h-4 bg-white rounded-full sound-bar" />
                    <div className="w-1 h-2 bg-white rounded-full sound-bar" />
                  </div>
                )}
              </div>
              
              <div className="min-w-0">
                <h4 className="font-medium text-sm truncate">
                  {currentSong.title}
                </h4>
                <p className="text-xs text-muted-foreground truncate">
                  {currentSong.artist?.name || 'Unknown Artist'}
                </p>
              </div>

              {/* Like Button */}
              <Button
                variant="ghost"
                size="icon"
                className={`flex-shrink-0 ${isLiked ? 'text-red-500' : 'text-muted-foreground'}`}
                onClick={handleLikeToggle}
              >
                <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
              </Button>
            </div>

            {/* Controls */}
            <div className="flex flex-col items-center gap-1 flex-1 max-w-md">
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-muted-foreground hover:text-foreground"
                  onClick={playPrevious}
                  disabled={queue.length === 0 || currentQueueIndex === 0}
                >
                  <SkipBack className="w-5 h-5" />
                </Button>
                
                <Button
                  size="icon"
                  className="w-10 h-10 rounded-full gradient-purple text-white hover:opacity-90"
                  onClick={togglePlay}
                >
                  {isPlaying ? (
                    <Pause className="w-5 h-5" />
                  ) : (
                    <Play className="w-5 h-5 ml-0.5" />
                  )}
                </Button>
                
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-muted-foreground hover:text-foreground"
                  onClick={playNext}
                  disabled={queue.length === 0 || currentQueueIndex >= queue.length - 1}
                >
                  <SkipForward className="w-5 h-5" />
                </Button>
              </div>
              
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span>{formatTime(currentTime)}</span>
                <span>/</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            {/* Right Controls */}
            <div className="flex items-center gap-2 flex-1 justify-end">
              {/* Lyrics Toggle */}
              {lyrics.length > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  className={`hidden sm:flex ${showLyrics ? 'text-primary' : 'text-muted-foreground'}`}
                  onClick={() => setShowLyrics(!showLyrics)}
                >
                  <ListMusic className="w-4 h-4 mr-1" />
                  Lyrics
                </Button>
              )}

              {/* Volume Control */}
              <div className="hidden sm:flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-muted-foreground"
                  onClick={() => setVolume(volume === 0 ? 0.8 : 0)}
                >
                  {volume === 0 ? (
                    <VolumeX className="w-5 h-5" />
                  ) : (
                    <Volume2 className="w-5 h-5" />
                  )}
                </Button>
                <Slider
                  value={[volume * 100]}
                  max={100}
                  step={1}
                  className="w-24"
                  onValueChange={(value) => setVolume(value[0] / 100)}
                />
              </div>

              {/* Mobile Lyrics Toggle */}
              {lyrics.length > 0 && (
                <Button
                  variant="ghost"
                  size="icon"
                  className={`sm:hidden ${showLyrics ? 'text-primary' : 'text-muted-foreground'}`}
                  onClick={() => setShowLyrics(!showLyrics)}
                >
                  <ListMusic className="w-5 h-5" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
