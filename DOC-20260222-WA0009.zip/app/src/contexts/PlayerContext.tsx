// =====================================================
// RaPut4 Music - Player Context
// =====================================================

import React, { createContext, useContext, useRef, useState, useCallback, useEffect } from 'react';
import type { Song, LyricLine } from '@/types';

interface PlayerContextType {
  currentSong: Song | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  lyrics: LyricLine[];
  currentLyricIndex: number;
  playSong: (song: Song) => void;
  togglePlay: () => void;
  pause: () => void;
  resume: () => void;
  seek: (time: number) => void;
  setVolume: (volume: number) => void;
  playNext: () => void;
  playPrevious: () => void;
  queue: Song[];
  setQueue: (songs: Song[]) => void;
  currentQueueIndex: number;
}

const PlayerContext = createContext<PlayerContextType | undefined>(undefined);

export function PlayerProvider({ children }: { children: React.ReactNode }) {
  const [currentSong, setCurrentSong] = useState<Song | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolumeState] = useState(0.8);
  const [queue, setQueue] = useState<Song[]>([]);
  const [currentQueueIndex, setCurrentQueueIndex] = useState(0);
  const [lyrics, setLyrics] = useState<LyricLine[]>([]);
  const [currentLyricIndex, setCurrentLyricIndex] = useState(-1);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Parse lyrics from timestamp format
  const parseLyrics = useCallback((lyricsText: string | null): LyricLine[] => {
    if (!lyricsText) return [];
    
    const lines = lyricsText.split('\n');
    const parsed: LyricLine[] = [];
    
    for (const line of lines) {
      const match = line.match(/\[(\d{2}):(\d{2})\](.*)/);
      if (match) {
        const minutes = parseInt(match[1], 10);
        const seconds = parseInt(match[2], 10);
        const text = match[3].trim();
        if (text) {
          parsed.push({
            time: minutes * 60 + seconds,
            text
          });
        }
      }
    }
    
    return parsed.sort((a, b) => a.time - b.time);
  }, []);

  // Initialize audio element
  useEffect(() => {
    const audio = new Audio();
    audioRef.current = audio;

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
      
      // Update current lyric index
      if (lyrics.length > 0) {
        const index = lyrics.findIndex((lyric, i) => {
          const nextLyric = lyrics[i + 1];
          return audio.currentTime >= lyric.time && 
                 (!nextLyric || audio.currentTime < nextLyric.time);
        });
        setCurrentLyricIndex(index >= 0 ? index : lyrics.length - 1);
      }
    };

    const handleLoadedMetadata = () => {
      setDuration(audio.duration);
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
      // Auto-play next song if available
      if (queue.length > 0 && currentQueueIndex < queue.length - 1) {
        playNext();
      }
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('ended', handleEnded);
      audio.pause();
    };
  }, [lyrics, queue, currentQueueIndex]);

  // Update audio source when song changes
  useEffect(() => {
    if (audioRef.current && currentSong) {
      audioRef.current.src = currentSong.audio_url;
      audioRef.current.volume = volume;
      if (isPlaying) {
        audioRef.current.play().catch(() => {
          setIsPlaying(false);
        });
      }
      // Parse lyrics for new song
      setLyrics(parseLyrics(currentSong.lyrics));
      setCurrentLyricIndex(-1);
    }
  }, [currentSong, volume, parseLyrics]);

  // Handle play/pause
  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch(() => {
          setIsPlaying(false);
        });
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying]);

  const playSong = useCallback((song: Song) => {
    setCurrentSong(song);
    setIsPlaying(true);
    setCurrentTime(0);
    setCurrentLyricIndex(-1);
  }, []);

  const togglePlay = useCallback(() => {
    if (currentSong) {
      setIsPlaying(prev => !prev);
    }
  }, [currentSong]);

  const pause = useCallback(() => {
    setIsPlaying(false);
  }, []);

  const resume = useCallback(() => {
    if (currentSong) {
      setIsPlaying(true);
    }
  }, [currentSong]);

  const seek = useCallback((time: number) => {
    if (audioRef.current) {
      audioRef.current.currentTime = time;
      setCurrentTime(time);
    }
  }, []);

  const setVolume = useCallback((newVolume: number) => {
    setVolumeState(newVolume);
    if (audioRef.current) {
      audioRef.current.volume = newVolume;
    }
  }, []);

  const playNext = useCallback(() => {
    if (queue.length > 0 && currentQueueIndex < queue.length - 1) {
      const nextIndex = currentQueueIndex + 1;
      setCurrentQueueIndex(nextIndex);
      playSong(queue[nextIndex]);
    }
  }, [queue, currentQueueIndex, playSong]);

  const playPrevious = useCallback(() => {
    if (queue.length > 0 && currentQueueIndex > 0) {
      const prevIndex = currentQueueIndex - 1;
      setCurrentQueueIndex(prevIndex);
      playSong(queue[prevIndex]);
    }
  }, [queue, currentQueueIndex, playSong]);

  const handleSetQueue = useCallback((songs: Song[]) => {
    setQueue(songs);
    if (currentSong) {
      const index = songs.findIndex(s => s.id === currentSong.id);
      setCurrentQueueIndex(index >= 0 ? index : 0);
    }
  }, [currentSong]);

  return (
    <PlayerContext.Provider
      value={{
        currentSong,
        isPlaying,
        currentTime,
        duration,
        volume,
        lyrics,
        currentLyricIndex,
        playSong,
        togglePlay,
        pause,
        resume,
        seek,
        setVolume,
        playNext,
        playPrevious,
        queue,
        setQueue: handleSetQueue,
        currentQueueIndex,
      }}
    >
      {children}
    </PlayerContext.Provider>
  );
}

export function usePlayer() {
  const context = useContext(PlayerContext);
  if (context === undefined) {
    throw new Error('usePlayer must be used within a PlayerProvider');
  }
  return context;
}
