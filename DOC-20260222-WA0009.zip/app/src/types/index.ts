// =====================================================
// RaPut4 Music - Type Definitions
// =====================================================

// User type from Supabase Auth
export interface User {
  id: string;
  email: string;
  created_at: string;
}

// Artist type
export interface Artist {
  id: string;
  name: string;
  image_url: string | null;
  bio: string | null;
  created_at: string;
  follower_count?: number;
  is_following?: boolean;
}

// Song type
export interface Song {
  id: string;
  title: string;
  artist_id: string | null;
  artist?: Artist;
  audio_url: string;
  cover_url: string | null;
  lyrics: string | null;
  user_id: string;
  created_at: string;
  like_count?: number;
  is_liked?: boolean;
}

// Artist Follower type
export interface ArtistFollower {
  id: string;
  user_id: string;
  artist_id: string;
  created_at: string;
}

// Liked Song type
export interface LikedSong {
  id: string;
  user_id: string;
  song_id: string;
  song?: Song;
  created_at: string;
}

// Playlist type
export interface Playlist {
  id: string;
  user_id: string;
  name: string;
  cover_url: string | null;
  created_at: string;
  song_count?: number;
}

// Playlist Song type
export interface PlaylistSong {
  id: string;
  playlist_id: string;
  song_id: string;
  song?: Song;
}

// Lyric line type for parsed lyrics
export interface LyricLine {
  time: number;
  text: string;
}

// Player state type
export interface PlayerState {
  currentSong: Song | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
}

// Upload form data type
export interface SongUploadData {
  title: string;
  artist_id: string | null;
  audio_url: string;
  cover_url: string | null;
  lyrics: string | null;
}

// Playlist form data type
export interface PlaylistFormData {
  name: string;
  cover_url: string | null;
}

// Artist form data type
export interface ArtistFormData {
  name: string;
  image_url: string | null;
  bio: string | null;
}
