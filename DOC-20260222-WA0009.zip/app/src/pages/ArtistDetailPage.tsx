// =====================================================
// RaPut4 Music - Artist Detail Page
// =====================================================

import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { usePlayer } from '@/contexts/PlayerContext';
import { Button } from '@/components/ui/button';
import { SongCard } from '@/components/songs/SongCard';
import { 
  ArrowLeft, 
  Users, 
  User, 
  Play,
  Heart,
  Share2,
  Music
} from 'lucide-react';
import type { Artist, Song } from '@/types';
import { 
  fetchArtistById, 
  fetchSongsByArtist, 
  followArtist, 
  unfollowArtist,
  supabase 
} from '@/lib/supabase';
import { toast } from 'sonner';

interface ArtistDetailPageProps {
  artistId: string;
}

export function ArtistDetailPage({ artistId }: ArtistDetailPageProps) {
  const [artist, setArtist] = useState<Artist | null>(null);
  const [songs, setSongs] = useState<Song[]>([]);
  const [loading, setLoading] = useState(true);
  const [isFollowing, setIsFollowing] = useState(false);
  const [followerCount, setFollowerCount] = useState(0);
  const { user } = useAuth();
  const { playSong, setQueue } = usePlayer();

  useEffect(() => {
    loadArtistData();
  }, [artistId, user]);

  const loadArtistData = async () => {
    setLoading(true);
    try {
      // Fetch artist
      const { data: artistData } = await fetchArtistById(artistId);
      if (artistData) {
        setArtist(artistData);

        // Fetch follower count
        const { count } = await supabase
          .from('artist_followers')
          .select('*', { count: 'exact', head: true })
          .eq('artist_id', artistId);
        setFollowerCount(count || 0);

        // Check if user follows this artist
        if (user) {
          const { data: followData } = await supabase
            .from('artist_followers')
            .select('*')
            .eq('artist_id', artistId)
            .eq('user_id', user.id)
            .single();
          setIsFollowing(!!followData);
        }
      }

      // Fetch songs
      const { data: songsData } = await fetchSongsByArtist(artistId);
      if (songsData) {
        // Fetch like counts for each song
        const songsWithLikes = await Promise.all(
          songsData.map(async (song) => {
            const { count } = await supabase
              .from('liked_songs')
              .select('*', { count: 'exact', head: true })
              .eq('song_id', song.id);
            return { ...song, like_count: count || 0 };
          })
        );
        setSongs(songsWithLikes);
      }
    } catch (error) {
      console.error('Error loading artist data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFollow = async () => {
    if (!user) {
      toast.error('Please sign in to follow artists');
      return;
    }

    try {
      if (isFollowing) {
        await unfollowArtist(user.id, artistId);
        setIsFollowing(false);
        setFollowerCount(prev => prev - 1);
        toast.success(`Unfollowed ${artist?.name}`);
      } else {
        await followArtist(user.id, artistId);
        setIsFollowing(true);
        setFollowerCount(prev => prev + 1);
        toast.success(`Following ${artist?.name}`);
      }
    } catch (error) {
      toast.error('Failed to update follow status');
    }
  };

  const handlePlayAll = () => {
    if (songs.length > 0) {
      setQueue(songs);
      playSong(songs[0]);
    }
  };

  const navigate = (page: string) => {
    window.dispatchEvent(new CustomEvent('navigate', { detail: { page } }));
  };

  if (loading) {
    return (
      <div className="min-h-screen py-8 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 w-32 bg-muted rounded mb-6" />
            <div className="flex gap-6 mb-8">
              <div className="w-48 h-48 bg-muted rounded-2xl" />
              <div className="flex-1 space-y-4">
                <div className="h-10 w-64 bg-muted rounded" />
                <div className="h-6 w-32 bg-muted rounded" />
                <div className="h-20 w-full max-w-lg bg-muted rounded" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!artist) {
    return (
      <div className="min-h-screen py-8 px-4">
        <div className="max-w-7xl mx-auto text-center py-20">
          <User className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
          <h2 className="text-2xl font-bold mb-2">Artist not found</h2>
          <p className="text-muted-foreground mb-4">The artist you're looking for doesn't exist</p>
          <Button onClick={() => navigate('artists')}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Artists
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="relative">
        {/* Background Gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-primary/10 to-background h-64" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Back Button */}
          <Button
            variant="ghost"
            className="mb-6"
            onClick={() => navigate('artists')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Artists
          </Button>

          {/* Artist Info */}
          <div className="flex flex-col md:flex-row gap-6 md:gap-8">
            {/* Artist Image */}
            <div className="w-48 h-48 md:w-64 md:h-64 rounded-2xl overflow-hidden flex-shrink-0 bg-muted mx-auto md:mx-0">
              {artist.image_url ? (
                <img
                  src={artist.image_url}
                  alt={artist.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-accent/20">
                  <User className="w-24 h-24 text-primary/50" />
                </div>
              )}
            </div>

            {/* Artist Details */}
            <div className="flex-1 text-center md:text-left">
              <h1 className="text-3xl md:text-5xl font-bold mb-2">{artist.name}</h1>
              
              <div className="flex items-center justify-center md:justify-start gap-4 mb-4">
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Users className="w-4 h-4" />
                  <span>{followerCount.toLocaleString()} followers</span>
                </div>
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Music className="w-4 h-4" />
                  <span>{songs.length} songs</span>
                </div>
              </div>

              {artist.bio && (
                <p className="text-muted-foreground max-w-lg mb-6 line-clamp-3">
                  {artist.bio}
                </p>
              )}

              <div className="flex items-center justify-center md:justify-start gap-3">
                <Button
                  className="gradient-purple text-white"
                  onClick={handlePlayAll}
                  disabled={songs.length === 0}
                >
                  <Play className="w-4 h-4 mr-2" />
                  Play All
                </Button>
                
                {user && (
                  <Button
                    variant={isFollowing ? 'outline' : 'default'}
                    onClick={handleFollow}
                  >
                    <Heart className={`w-4 h-4 mr-2 ${isFollowing ? 'fill-current' : ''}`} />
                    {isFollowing ? 'Following' : 'Follow'}
                  </Button>
                )}
                
                <Button variant="outline" size="icon">
                  <Share2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Songs Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h2 className="text-2xl font-bold mb-6">Songs</h2>
        
        {songs.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {songs.map((song) => (
              <SongCard key={song.id} song={song} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Music className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">No songs yet</p>
          </div>
        )}
      </div>
    </div>
  );
}
