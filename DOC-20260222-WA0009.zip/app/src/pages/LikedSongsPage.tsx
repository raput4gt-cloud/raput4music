// =====================================================
// RaPut4 Music - Liked Songs Page
// =====================================================

import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { usePlayer } from '@/contexts/PlayerContext';
import { SongCard } from '@/components/songs/SongCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Heart, Play, Search, ArrowLeft } from 'lucide-react';
import type { Song } from '@/types';
import { fetchLikedSongs, supabase } from '@/lib/supabase';

export function LikedSongsPage() {
  const { user } = useAuth();
  const [songs, setSongs] = useState<Song[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const { playSong, setQueue } = usePlayer();

  useEffect(() => {
    if (user) {
      loadLikedSongs();
    }
  }, [user]);

  const loadLikedSongs = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { data } = await fetchLikedSongs(user.id);
      if (data) {
        // Extract songs from liked_songs and fetch like counts
        const likedSongs = data
          .map((ls: any) => ls.song)
          .filter(Boolean);
        
        const songsWithLikes = await Promise.all(
          likedSongs.map(async (song: Song) => {
            const { count } = await supabase
              .from('liked_songs')
              .select('*', { count: 'exact', head: true })
              .eq('song_id', song.id);
            return { ...song, like_count: count || 0, is_liked: true };
          })
        );
        
        setSongs(songsWithLikes);
      }
    } catch (error) {
      console.error('Error loading liked songs:', error);
    } finally {
      setLoading(false);
    }
  };

  // Filter songs based on search
  const filteredSongs = songs.filter(song =>
    song.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    song.artist?.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handlePlayAll = () => {
    if (songs.length > 0) {
      setQueue(songs);
      playSong(songs[0]);
    }
  };

  const navigate = (page: string) => {
    window.dispatchEvent(new CustomEvent('navigate', { detail: { page } }));
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="relative">
        {/* Background Gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-red-500/10 to-background h-64" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Back Button */}
          <Button
            variant="ghost"
            className="mb-6"
            onClick={() => navigate('home')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>

          {/* Page Info */}
          <div className="flex flex-col md:flex-row gap-6 md:gap-8 items-start">
            {/* Icon */}
            <div className="w-32 h-32 md:w-48 md:h-48 rounded-2xl bg-gradient-to-br from-red-500 to-pink-600 flex items-center justify-center flex-shrink-0 mx-auto md:mx-0">
              <Heart className="w-16 h-16 md:w-24 md:h-24 text-white" />
            </div>

            {/* Details */}
            <div className="flex-1 text-center md:text-left">
              <p className="text-sm text-muted-foreground uppercase tracking-wider mb-2">
                Playlist
              </p>
              <h1 className="text-3xl md:text-5xl font-bold mb-4">Liked Songs</h1>
              
              <div className="flex items-center justify-center md:justify-start gap-4 mb-6">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <span>{songs.length} songs</span>
                </div>
              </div>

              <Button
                className="gradient-purple text-white"
                onClick={handlePlayAll}
                disabled={songs.length === 0}
              >
                <Play className="w-4 h-4 mr-2" />
                Play All
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Songs Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search liked songs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        <h2 className="text-2xl font-bold mb-6">Your Liked Songs</h2>
        
        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="aspect-square rounded-xl bg-muted animate-pulse" />
            ))}
          </div>
        ) : filteredSongs.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {filteredSongs.map((song) => (
              <SongCard key={song.id} song={song} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Heart className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground mb-2">
              {searchQuery ? 'No songs match your search' : 'No liked songs yet'}
            </p>
            {!searchQuery && (
              <Button onClick={() => navigate('home')} className="mt-4">
                Discover Music
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
