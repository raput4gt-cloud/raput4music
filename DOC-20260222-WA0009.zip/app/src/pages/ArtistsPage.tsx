// =====================================================
// RaPut4 Music - Artists Page
// =====================================================

import { useEffect, useState } from 'react';
import { ArtistCard, ArtistCardCompact } from '@/components/artists/ArtistCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Search, Grid3X3, List, Plus } from 'lucide-react';
import type { Artist } from '@/types';
import { fetchArtists, supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { createArtist, uploadArtistImage } from '@/lib/supabase';
import { toast } from 'sonner';

export function ArtistsPage() {
  const [artists, setArtists] = useState<Artist[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const { user } = useAuth();

  // New artist form state
  const [newArtistName, setNewArtistName] = useState('');
  const [newArtistBio, setNewArtistBio] = useState('');
  const [newArtistImage, setNewArtistImage] = useState<File | null>(null);
  const [newArtistImageUrl, setNewArtistImageUrl] = useState('');
  const [creating, setCreating] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);

  useEffect(() => {
    loadArtists();
  }, []);

  const loadArtists = async () => {
    setLoading(true);
    try {
      const { data } = await fetchArtists();
      if (data) {
        // Fetch follower counts and follow status for each artist
        const artistsWithData = await Promise.all(
          data.map(async (artist) => {
            const { count: followerCount } = await supabase
              .from('artist_followers')
              .select('*', { count: 'exact', head: true })
              .eq('artist_id', artist.id);
            
            let isFollowing = false;
            if (user) {
              const { data: followData } = await supabase
                .from('artist_followers')
                .select('*')
                .eq('artist_id', artist.id)
                .eq('user_id', user.id)
                .single();
              isFollowing = !!followData;
            }
            
            return {
              ...artist,
              follower_count: followerCount || 0,
              is_following: isFollowing
            };
          })
        );
        setArtists(artistsWithData);
      }
    } catch (error) {
      console.error('Error loading artists:', error);
    } finally {
      setLoading(false);
    }
  };

  // Filter artists based on search
  const filteredArtists = artists.filter(artist =>
    artist.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const navigate = (page: string, params?: Record<string, string>) => {
    window.dispatchEvent(new CustomEvent('navigate', { detail: { page, params } }));
  };

  // Handle create artist
  const handleCreateArtist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newArtistName.trim()) {
      toast.error('Please enter an artist name');
      return;
    }

    setCreating(true);
    try {
      let imageUrl = newArtistImageUrl;

      // Upload image if provided
      if (newArtistImage && user) {
        imageUrl = await uploadArtistImage(newArtistImage, user.id);
      }

      await createArtist({
        name: newArtistName,
        bio: newArtistBio || null,
        image_url: imageUrl || null
      });

      toast.success('Artist created successfully');
      setDialogOpen(false);
      setNewArtistName('');
      setNewArtistBio('');
      setNewArtistImage(null);
      setNewArtistImageUrl('');
      loadArtists();
    } catch (error) {
      toast.error('Failed to create artist');
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl gradient-purple flex items-center justify-center">
                <Users className="w-5 h-5 text-white" />
              </div>
              Artists
            </h1>
            <p className="text-muted-foreground mt-1">
              Discover and follow your favorite artists
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button className="gradient-purple text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Artist
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Add New Artist</DialogTitle>
                  <DialogDescription>
                    Create a new artist profile
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleCreateArtist} className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Name *</label>
                    <Input
                      value={newArtistName}
                      onChange={(e) => setNewArtistName(e.target.value)}
                      placeholder="Artist name"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Bio</label>
                    <textarea
                      value={newArtistBio}
                      onChange={(e) => setNewArtistBio(e.target.value)}
                      placeholder="Artist biography"
                      className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
                      rows={3}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Image URL</label>
                    <Input
                      value={newArtistImageUrl}
                      onChange={(e) => setNewArtistImageUrl(e.target.value)}
                      placeholder="https://..."
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Or Upload Image</label>
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={(e) => setNewArtistImage(e.target.files?.[0] || null)}
                    />
                  </div>
                  <Button type="submit" className="w-full gradient-purple text-white" disabled={creating}>
                    {creating ? 'Creating...' : 'Create Artist'}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Search and View Toggle */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search artists..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'outline'}
              size="icon"
              onClick={() => setViewMode('grid')}
            >
              <Grid3X3 className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'outline'}
              size="icon"
              onClick={() => setViewMode('list')}
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Artists Grid/List */}
        {loading ? (
          viewMode === 'grid' ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {[...Array(12)].map((_, i) => (
                <div key={i} className="aspect-square rounded-xl bg-muted animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="h-20 rounded-xl bg-muted animate-pulse" />
              ))}
            </div>
          )
        ) : filteredArtists.length > 0 ? (
          viewMode === 'grid' ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {filteredArtists.map((artist) => (
                <ArtistCard
                  key={artist.id}
                  artist={artist}
                  onClick={() => navigate('artist-detail', { artistId: artist.id })}
                />
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {filteredArtists.map((artist) => (
                <ArtistCardCompact
                  key={artist.id}
                  artist={artist}
                  onClick={() => navigate('artist-detail', { artistId: artist.id })}
                />
              ))}
            </div>
          )
        ) : (
          <div className="text-center py-20">
            <Users className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No artists found</h3>
            <p className="text-muted-foreground mb-4">
              {searchQuery ? 'Try a different search term' : 'Be the first to add an artist'}
            </p>
            {!searchQuery && (
              <Button onClick={() => setDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Artist
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
