// =====================================================
// RaPut4 Music - Dashboard Page
// =====================================================

import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { SongCard } from '@/components/songs/SongCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  LayoutDashboard, 
  Music, 
  Heart, 
  Users,
  Plus,
  Search,
  Edit3,
  Trash2
} from 'lucide-react';
import type { Song } from '@/types';
import { fetchSongsByUser, deleteSong, supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

export function DashboardPage() {
  const { user } = useAuth();
  const [songs, setSongs] = useState<Song[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState({
    totalSongs: 0,
    totalLikes: 0,
    totalPlays: 0
  });

  // Edit dialog state
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingSong, setEditingSong] = useState<Song | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editLyrics, setEditLyrics] = useState('');

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    if (!user) return;
    setLoading(true);
    try {
      // Fetch user's songs
      const { data: songsData } = await fetchSongsByUser(user.id);
      if (songsData) {
        // Fetch like counts for each song
        const songsWithLikes = await Promise.all(
          songsData.map(async (song) => {
            const { count } = await supabase
              .from('liked_songs')
              .select('*', { count: 'exact', head: true })
              .eq('song_id', song.id);
            return { ...song, like_count: count || 0 };
          })
        );
        setSongs(songsWithLikes);

        // Calculate stats
        const totalLikes = songsWithLikes.reduce((sum, song) => sum + (song.like_count || 0), 0);
        setStats({
          totalSongs: songsWithLikes.length,
          totalLikes,
          totalPlays: 0 // Would need a plays table for this
        });
      }
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Filter songs based on search
  const filteredSongs = songs.filter(song =>
    song.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const navigate = (page: string) => {
    window.dispatchEvent(new CustomEvent('navigate', { detail: { page } }));
  };

  const handleDelete = async (song: Song) => {
    if (!confirm(`Are you sure you want to delete "${song.title}"?`)) return;

    try {
      await deleteSong(song.id);
      toast.success('Song deleted successfully');
      loadData();
    } catch (error) {
      toast.error('Failed to delete song');
    }
  };

  const handleEdit = (song: Song) => {
    setEditingSong(song);
    setEditTitle(song.title);
    setEditLyrics(song.lyrics || '');
    setEditDialogOpen(true);
  };

  const handleSaveEdit = async () => {
    if (!editingSong) return;

    try {
      await supabase
        .from('songs')
        .update({ title: editTitle, lyrics: editLyrics })
        .eq('id', editingSong.id);
      
      toast.success('Song updated successfully');
      setEditDialogOpen(false);
      loadData();
    } catch (error) {
      toast.error('Failed to update song');
    }
  };

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl gradient-purple flex items-center justify-center">
                <LayoutDashboard className="w-5 h-5 text-white" />
              </div>
              Dashboard
            </h1>
            <p className="text-muted-foreground mt-1">
              Manage your music and track your stats
            </p>
          </div>

          <Button className="gradient-purple text-white" onClick={() => navigate('upload')}>
            <Plus className="w-4 h-4 mr-2" />
            Upload New Song
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <div className="bg-card rounded-xl p-6 border border-border">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <Music className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalSongs}</p>
                <p className="text-sm text-muted-foreground">Total Songs</p>
              </div>
            </div>
          </div>

          <div className="bg-card rounded-xl p-6 border border-border">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center">
                <Heart className="w-6 h-6 text-red-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalLikes}</p>
                <p className="text-sm text-muted-foreground">Total Likes</p>
              </div>
            </div>
          </div>

          <div className="bg-card rounded-xl p-6 border border-border">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center">
                <Users className="w-6 h-6 text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalPlays}</p>
                <p className="text-sm text-muted-foreground">Total Plays</p>
              </div>
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search your songs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Songs Grid */}
        <div>
          <h2 className="text-xl font-bold mb-4">Your Songs</h2>
          
          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="aspect-square rounded-xl bg-muted animate-pulse" />
              ))}
            </div>
          ) : filteredSongs.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {filteredSongs.map((song) => (
                <SongCard 
                  key={song.id} 
                  song={song}
                  onEdit={handleEdit}
                  onDelete={handleDelete}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Music className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground mb-2">
                {searchQuery ? 'No songs match your search' : 'No songs uploaded yet'}
              </p>
              {!searchQuery && (
                <Button onClick={() => navigate('upload')} className="mt-4">
                  <Plus className="w-4 h-4 mr-2" />
                  Upload Your First Song
                </Button>
              )}
            </div>
          )}
        </div>

        {/* Edit Dialog */}
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Edit Song</DialogTitle>
              <DialogDescription>
                Update your song details
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Title</label>
                <Input
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  placeholder="Song title"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Lyrics</label>
                <textarea
                  value={editLyrics}
                  onChange={(e) => setEditLyrics(e.target.value)}
                  placeholder="[00:00] Line 1\n[00:05] Line 2"
                  className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm font-mono"
                  rows={10}
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Use format: [MM:SS] Lyric line
                </p>
              </div>
              <Button onClick={handleSaveEdit} className="w-full gradient-purple text-white">
                Save Changes
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
