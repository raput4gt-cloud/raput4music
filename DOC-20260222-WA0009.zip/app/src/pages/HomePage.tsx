// =====================================================
// RaPut4 Music - Home Page
// =====================================================

import { useEffect, useState } from 'react';
import { usePlayer } from '@/contexts/PlayerContext';
import { SongCard } from '@/components/songs/SongCard';
import { ArtistCard } from '@/components/artists/ArtistCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Music, 
  Search, 
  Sparkles, 
  Headphones,
  Zap,
  Globe
} from 'lucide-react';
import type { Song, Artist } from '@/types';
import { fetchSongs, fetchArtists, supabase } from '@/lib/supabase';

export function HomePage() {
  const [songs, setSongs] = useState<Song[]>([]);
  const [artists, setArtists] = useState<Artist[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const { setQueue } = usePlayer();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      // Fetch songs with artist info
      const { data: songsData } = await fetchSongs();
      if (songsData) {
        // Fetch like counts for each song
        const songsWithLikes = await Promise.all(
          songsData.map(async (song) => {
            const { count } = await supabase
              .from('liked_songs')
              .select('*', { count: 'exact', head: true })
              .eq('song_id', song.id);
            return { ...song, like_count: count || 0 };
          })
        );
        setSongs(songsWithLikes);
        setQueue(songsWithLikes);
      }

      // Fetch artists with follower counts
      const { data: artistsData } = await fetchArtists();
      if (artistsData) {
        const artistsWithFollowers = await Promise.all(
          artistsData.map(async (artist) => {
            const { count } = await supabase
              .from('artist_followers')
              .select('*', { count: 'exact', head: true })
              .eq('artist_id', artist.id);
            return { ...artist, follower_count: count || 0 };
          })
        );
        setArtists(artistsWithFollowers);
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Filter songs based on search
  const filteredSongs = songs.filter(song =>
    song.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    song.artist?.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Filter artists based on search
  const filteredArtists = artists.filter(artist =>
    artist.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const navigate = (page: string, params?: Record<string, string>) => {
    window.dispatchEvent(new CustomEvent('navigate', { detail: { page, params } }));
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Background Gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-accent/10" />
        
        {/* Decorative Elements */}
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/20 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
        
        <div className="relative max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
            <Sparkles className="w-4 h-4" />
            All Music. Zero Barriers.
          </div>
          
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
            Discover & Share
            <span className="block bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Music Freely
            </span>
          </h1>
          
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            RaPut4 Music is a completely free platform for creators and listeners. 
            No subscriptions, no limits - just pure music.
          </p>

          {/* Search Bar */}
          <div className="max-w-xl mx-auto relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search songs, artists..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 pr-4 py-6 text-lg rounded-full bg-card border-border"
            />
          </div>

          {/* Stats */}
          <div className="flex flex-wrap justify-center gap-8 mt-12">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <Music className="w-6 h-6 text-primary" />
              </div>
              <div className="text-left">
                <p className="text-2xl font-bold">{songs.length}</p>
                <p className="text-sm text-muted-foreground">Songs</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center">
                <Headphones className="w-6 h-6 text-accent" />
              </div>
              <div className="text-left">
                <p className="text-2xl font-bold">{artists.length}</p>
                <p className="text-sm text-muted-foreground">Artists</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <div className="text-left">
                <p className="text-2xl font-bold">100%</p>
                <p className="text-sm text-muted-foreground">Free</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Songs Section */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold">Trending Songs</h2>
              <p className="text-muted-foreground">Discover the latest tracks</p>
            </div>
            <Button variant="outline" onClick={() => navigate('upload')}>
              <Music className="w-4 h-4 mr-2" />
              Upload Song
            </Button>
          </div>

          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="aspect-square rounded-xl bg-muted animate-pulse" />
              ))}
            </div>
          ) : filteredSongs.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {filteredSongs.slice(0, 10).map((song) => (
                <SongCard key={song.id} song={song} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Music className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No songs found</p>
            </div>
          )}
        </div>
      </section>

      {/* Artists Section */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 border-t border-border">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold">Featured Artists</h2>
              <p className="text-muted-foreground">Follow your favorites</p>
            </div>
            <Button variant="outline" onClick={() => navigate('artists')}>
              <Globe className="w-4 h-4 mr-2" />
              View All
            </Button>
          </div>

          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="aspect-square rounded-xl bg-muted animate-pulse" />
              ))}
            </div>
          ) : filteredArtists.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {filteredArtists.slice(0, 6).map((artist) => (
                <ArtistCard
                  key={artist.id}
                  artist={artist}
                  onClick={() => navigate('artist-detail', { artistId: artist.id })}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Headphones className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No artists found</p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 border-t border-border">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Share Your Music?</h2>
          <p className="text-muted-foreground mb-8">
            Join our community of creators and listeners. Upload your tracks, build your audience, 
            and discover new music - all for free.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" className="gradient-purple text-white" onClick={() => navigate('upload')}>
              <Upload className="w-5 h-5 mr-2" />
              Upload Your First Song
            </Button>
            <Button size="lg" variant="outline" onClick={() => navigate('register')}>
              Create Account
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}

// Import Upload icon
import { Upload } from 'lucide-react';
