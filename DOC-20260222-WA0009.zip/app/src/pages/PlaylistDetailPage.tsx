// =====================================================
// RaPut4 Music - Playlist Detail Page
// =====================================================

import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { usePlayer } from '@/contexts/PlayerContext';
import { Button } from '@/components/ui/button';
import { SongCard } from '@/components/songs/SongCard';
import { 
  ArrowLeft, 
  ListMusic, 
  Play, 
  Shuffle,
  Clock,
  Music,
  Trash2
} from 'lucide-react';
import type { Playlist, Song } from '@/types';
import { fetchPlaylistById, removeSongFromPlaylist, supabase } from '@/lib/supabase';
import { toast } from 'sonner';

interface PlaylistDetailPageProps {
  playlistId: string;
}

export function PlaylistDetailPage({ playlistId }: PlaylistDetailPageProps) {
  const [playlist, setPlaylist] = useState<Playlist | null>(null);
  const [songs, setSongs] = useState<Song[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const { playSong, setQueue } = usePlayer();

  useEffect(() => {
    loadPlaylist();
  }, [playlistId]);

  const loadPlaylist = async () => {
    setLoading(true);
    try {
      const { data } = await fetchPlaylistById(playlistId);
      if (data) {
        setPlaylist(data);
        
        // Extract songs from playlist_songs
        const playlistSongs = data.playlist_songs
          ?.map((ps: any) => ps.song)
          .filter(Boolean) || [];
        
        // Fetch like counts for each song
        const songsWithLikes = await Promise.all(
          playlistSongs.map(async (song: Song) => {
            const { count } = await supabase
              .from('liked_songs')
              .select('*', { count: 'exact', head: true })
              .eq('song_id', song.id);
            return { ...song, like_count: count || 0 };
          })
        );
        
        setSongs(songsWithLikes);
      }
    } catch (error) {
      console.error('Error loading playlist:', error);
    } finally {
      setLoading(false);
    }
  };

  const handlePlayAll = () => {
    if (songs.length > 0) {
      setQueue(songs);
      playSong(songs[0]);
    }
  };

  const handleShuffle = () => {
    if (songs.length > 0) {
      const shuffled = [...songs].sort(() => Math.random() - 0.5);
      setQueue(shuffled);
      playSong(shuffled[0]);
    }
  };

  const handleRemoveSong = async (song: Song) => {
    if (!confirm(`Remove "${song.title}" from this playlist?`)) return;
    
    try {
      await removeSongFromPlaylist(playlistId, song.id);
      toast.success('Song removed from playlist');
      loadPlaylist();
    } catch (error) {
      toast.error('Failed to remove song');
    }
  };

  const navigate = (page: string) => {
    window.dispatchEvent(new CustomEvent('navigate', { detail: { page } }));
  };

  // Calculate total duration (mock calculation)
  const totalDuration = songs.length * 3; // Assume 3 minutes per song

  if (loading) {
    return (
      <div className="min-h-screen py-8 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 w-32 bg-muted rounded mb-6" />
            <div className="flex gap-6 mb-8">
              <div className="w-48 h-48 bg-muted rounded-2xl" />
              <div className="flex-1 space-y-4">
                <div className="h-10 w-64 bg-muted rounded" />
                <div className="h-6 w-32 bg-muted rounded" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!playlist) {
    return (
      <div className="min-h-screen py-8 px-4">
        <div className="max-w-7xl mx-auto text-center py-20">
          <ListMusic className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
          <h2 className="text-2xl font-bold mb-2">Playlist not found</h2>
          <p className="text-muted-foreground mb-4">The playlist you're looking for doesn't exist</p>
          <Button onClick={() => navigate('playlists')}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Playlists
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="relative">
        {/* Background Gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-primary/10 to-background h-64" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Back Button */}
          <Button
            variant="ghost"
            className="mb-6"
            onClick={() => navigate('playlists')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Playlists
          </Button>

          {/* Playlist Info */}
          <div className="flex flex-col md:flex-row gap-6 md:gap-8">
            {/* Playlist Cover */}
            <div className="w-48 h-48 md:w-64 md:h-64 rounded-2xl overflow-hidden flex-shrink-0 bg-muted mx-auto md:mx-0">
              {playlist.cover_url ? (
                <img
                  src={playlist.cover_url}
                  alt={playlist.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-accent/20">
                  <ListMusic className="w-24 h-24 text-primary/50" />
                </div>
              )}
            </div>

            {/* Playlist Details */}
            <div className="flex-1 text-center md:text-left">
              <p className="text-sm text-muted-foreground uppercase tracking-wider mb-2">
                Playlist
              </p>
              <h1 className="text-3xl md:text-5xl font-bold mb-4">{playlist.name}</h1>
              
              <div className="flex items-center justify-center md:justify-start gap-4 mb-6">
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Music className="w-4 h-4" />
                  <span>{songs.length} songs</span>
                </div>
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  <span>~{totalDuration} min</span>
                </div>
              </div>

              <div className="flex items-center justify-center md:justify-start gap-3">
                <Button
                  className="gradient-purple text-white"
                  onClick={handlePlayAll}
                  disabled={songs.length === 0}
                >
                  <Play className="w-4 h-4 mr-2" />
                  Play All
                </Button>
                
                <Button
                  variant="outline"
                  onClick={handleShuffle}
                  disabled={songs.length === 0}
                >
                  <Shuffle className="w-4 h-4 mr-2" />
                  Shuffle
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Songs Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h2 className="text-2xl font-bold mb-6">Songs</h2>
        
        {songs.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {songs.map((song) => (
              <SongCard 
                key={song.id} 
                song={song}
                onDelete={(s) => handleRemoveSong(s)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Music className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground mb-2">No songs in this playlist yet</p>
            <p className="text-sm text-muted-foreground">
              Browse songs and add them to this playlist
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
