// =====================================================
// RaPut4 Music - Upload Page
// =====================================================

import { useState, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Upload, 
  Music, 
  Image as ImageIcon, 
  FileAudio,
  Link as LinkIcon,
  X,
  Check,
  ArrowLeft
} from 'lucide-react';
import { createSong, uploadAudioFile, uploadCoverImage, fetchArtists } from '@/lib/supabase';
import { toast } from 'sonner';
import type { Artist } from '@/types';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export function UploadPage() {
  const { user } = useAuth();
  const [step, setStep] = useState(1);
  const [uploading, setUploading] = useState(false);
  
  // Form state
  const [title, setTitle] = useState('');
  const [artistId, setArtistId] = useState('');
  const [artists, setArtists] = useState<Artist[]>([]);
  const [audioUrl, setAudioUrl] = useState('');
  const [coverUrl, setCoverUrl] = useState('');
  const [lyrics, setLyrics] = useState('');
  
  // File state
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [audioPreview, setAudioPreview] = useState('');
  const [coverPreview, setCoverPreview] = useState('');
  
  // Input mode
  const [audioMode, setAudioMode] = useState<'file' | 'url'>('file');
  const [coverMode, setCoverMode] = useState<'file' | 'url'>('file');

  const audioInputRef = useRef<HTMLInputElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);

  // Load artists on mount
  const loadArtists = async () => {
    const { data } = await fetchArtists();
    if (data) {
      setArtists(data);
    }
  };

  useState(() => {
    loadArtists();
  });

  // Handle audio file selection
  const handleAudioFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 50 * 1024 * 1024) { // 50MB limit
        toast.error('Audio file must be less than 50MB');
        return;
      }
      setAudioFile(file);
      setAudioPreview(URL.createObjectURL(file));
    }
  };

  // Handle cover file selection
  const handleCoverFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast.error('Cover image must be less than 5MB');
        return;
      }
      setCoverFile(file);
      setCoverPreview(URL.createObjectURL(file));
    }
  };

  // Handle upload
  const handleUpload = async () => {
    if (!user) {
      toast.error('Please sign in to upload');
      return;
    }

    if (!title.trim()) {
      toast.error('Please enter a song title');
      return;
    }

    setUploading(true);
    try {
      let finalAudioUrl = audioUrl;
      let finalCoverUrl = coverUrl;

      // Upload audio file if selected
      if (audioMode === 'file' && audioFile) {
        finalAudioUrl = await uploadAudioFile(audioFile, user.id);
      }

      // Upload cover image if selected
      if (coverMode === 'file' && coverFile) {
        finalCoverUrl = await uploadCoverImage(coverFile, user.id);
      }

      // Validate audio URL
      if (!finalAudioUrl) {
        toast.error('Please provide an audio file or URL');
        setUploading(false);
        return;
      }

      // Create song record
      await createSong({
        title: title.trim(),
        artist_id: artistId || null,
        audio_url: finalAudioUrl,
        cover_url: finalCoverUrl || null,
        lyrics: lyrics.trim() || null,
        user_id: user.id
      });

      toast.success('Song uploaded successfully!');
      
      // Reset form
      setTitle('');
      setArtistId('');
      setAudioUrl('');
      setCoverUrl('');
      setLyrics('');
      setAudioFile(null);
      setCoverFile(null);
      setAudioPreview('');
      setCoverPreview('');
      
      // Navigate to dashboard
      navigate('dashboard');
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload song. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const navigate = (page: string) => {
    window.dispatchEvent(new CustomEvent('navigate', { detail: { page } }));
  };

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Back Button */}
        <Button
          variant="ghost"
          className="mb-6"
          onClick={() => navigate('dashboard')}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Button>

        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl gradient-purple flex items-center justify-center">
                <Upload className="w-5 h-5 text-white" />
              </div>
              Upload Song
            </CardTitle>
            <CardDescription>
              Share your music with the world. All uploads are free!
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Step 1: Song Info */}
            <div className="space-y-4">
              <h3 className="font-semibold flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                  1
                </span>
                Song Information
              </h3>

              <div className="space-y-2">
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  placeholder="Enter song title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="artist">Artist</Label>
                <Select value={artistId} onValueChange={setArtistId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select an artist (optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    {artists.map((artist) => (
                      <SelectItem key={artist.id} value={artist.id}>
                        {artist.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Step 2: Audio */}
            <div className="space-y-4">
              <h3 className="font-semibold flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                  2
                </span>
                Audio
              </h3>

              <div className="flex gap-2 mb-4">
                <Button
                  type="button"
                  variant={audioMode === 'file' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setAudioMode('file')}
                >
                  <FileAudio className="w-4 h-4 mr-2" />
                  Upload File
                </Button>
                <Button
                  type="button"
                  variant={audioMode === 'url' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setAudioMode('url')}
                >
                  <LinkIcon className="w-4 h-4 mr-2" />
                  External URL
                </Button>
              </div>

              {audioMode === 'file' ? (
                <div
                  className="border-2 border-dashed border-border rounded-xl p-8 text-center cursor-pointer hover:border-primary/50 transition-colors"
                  onClick={() => audioInputRef.current?.click()}
                >
                  <input
                    ref={audioInputRef}
                    type="file"
                    accept="audio/*"
                    className="hidden"
                    onChange={handleAudioFileChange}
                  />
                  {audioFile ? (
                    <div className="flex items-center justify-center gap-2">
                      <Check className="w-5 h-5 text-green-500" />
                      <span>{audioFile.name}</span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={(e) => {
                          e.stopPropagation();
                          setAudioFile(null);
                          setAudioPreview('');
                        }}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ) : (
                    <>
                      <FileAudio className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
                      <p className="text-muted-foreground">
                        Click to upload audio file
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        MP3, WAV, OGG up to 50MB
                      </p>
                    </>
                  )}
                </div>
              ) : (
                <div className="space-y-2">
                  <Label>Audio URL</Label>
                  <Input
                    placeholder="https://example.com/song.mp3"
                    value={audioUrl}
                    onChange={(e) => setAudioUrl(e.target.value)}
                  />
                </div>
              )}
            </div>

            {/* Step 3: Cover Image */}
            <div className="space-y-4">
              <h3 className="font-semibold flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                  3
                </span>
                Cover Image (Optional)
              </h3>

              <div className="flex gap-2 mb-4">
                <Button
                  type="button"
                  variant={coverMode === 'file' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setCoverMode('file')}
                >
                  <ImageIcon className="w-4 h-4 mr-2" />
                  Upload Image
                </Button>
                <Button
                  type="button"
                  variant={coverMode === 'url' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setCoverMode('url')}
                >
                  <LinkIcon className="w-4 h-4 mr-2" />
                  External URL
                </Button>
              </div>

              {coverMode === 'file' ? (
                <div
                  className="border-2 border-dashed border-border rounded-xl p-8 text-center cursor-pointer hover:border-primary/50 transition-colors"
                  onClick={() => coverInputRef.current?.click()}
                >
                  <input
                    ref={coverInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleCoverFileChange}
                  />
                  {coverFile ? (
                    <div className="flex items-center justify-center gap-2">
                      <img
                        src={coverPreview}
                        alt="Cover preview"
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                      <span>{coverFile.name}</span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={(e) => {
                          e.stopPropagation();
                          setCoverFile(null);
                          setCoverPreview('');
                        }}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ) : (
                    <>
                      <ImageIcon className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
                      <p className="text-muted-foreground">
                        Click to upload cover image
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        JPG, PNG up to 5MB
                      </p>
                    </>
                  )}
                </div>
              ) : (
                <div className="space-y-2">
                  <Label>Cover Image URL</Label>
                  <Input
                    placeholder="https://example.com/cover.jpg"
                    value={coverUrl}
                    onChange={(e) => setCoverUrl(e.target.value)}
                  />
                </div>
              )}
            </div>

            {/* Step 4: Lyrics */}
            <div className="space-y-4">
              <h3 className="font-semibold flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                  4
                </span>
                Lyrics (Optional)
              </h3>

              <div className="space-y-2">
                <textarea
                  value={lyrics}
                  onChange={(e) => setLyrics(e.target.value)}
                  placeholder="[00:00] First line of lyrics\n[00:05] Second line of lyrics\n[00:10] Third line of lyrics"
                  className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm font-mono"
                  rows={8}
                />
                <p className="text-xs text-muted-foreground">
                  Use timestamp format [MM:SS] for auto-sync lyrics
                </p>
              </div>
            </div>

            {/* Submit Button */}
            <Button
              onClick={handleUpload}
              disabled={uploading || !title.trim() || (audioMode === 'file' ? !audioFile : !audioUrl)}
              className="w-full gradient-purple text-white h-12"
            >
              {uploading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2" />
                  Uploading...
                </>
              ) : (
                <>
                  <Upload className="w-5 h-5 mr-2" />
                  Upload Song
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
