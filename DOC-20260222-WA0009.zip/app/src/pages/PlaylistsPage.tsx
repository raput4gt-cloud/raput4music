// =====================================================
// RaPut4 Music - Playlists Page
// =====================================================

import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { PlaylistCard, PlaylistCardCompact } from '@/components/playlists/PlaylistCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { ListMusic, Plus, Grid3X3, List, Search } from 'lucide-react';
import type { Playlist } from '@/types';
import { fetchPlaylists, createPlaylist } from '@/lib/supabase';
import { toast } from 'sonner';

export function PlaylistsPage() {
  const { user } = useAuth();
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  
  // New playlist form state
  const [newPlaylistName, setNewPlaylistName] = useState('');
  const [creating, setCreating] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);

  useEffect(() => {
    if (user) {
      loadPlaylists();
    }
  }, [user]);

  const loadPlaylists = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { data } = await fetchPlaylists(user.id);
      if (data) {
        // Fetch song counts for each playlist
        const playlistsWithCounts = await Promise.all(
          data.map(async (playlist) => {
            const { count } = await import('@/lib/supabase').then(m => 
              m.supabase
                .from('playlist_songs')
                .select('*', { count: 'exact', head: true })
                .eq('playlist_id', playlist.id)
            );
            return { ...playlist, song_count: count || 0 };
          })
        );
        setPlaylists(playlistsWithCounts);
      }
    } catch (error) {
      console.error('Error loading playlists:', error);
    } finally {
      setLoading(false);
    }
  };

  // Filter playlists based on search
  const filteredPlaylists = playlists.filter(playlist =>
    playlist.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const navigate = (page: string, params?: Record<string, string>) => {
    window.dispatchEvent(new CustomEvent('navigate', { detail: { page, params } }));
  };

  // Handle create playlist
  const handleCreatePlaylist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlaylistName.trim() || !user) {
      toast.error('Please enter a playlist name');
      return;
    }

    setCreating(true);
    try {
      await createPlaylist(user.id, newPlaylistName, null);
      toast.success('Playlist created successfully');
      setDialogOpen(false);
      setNewPlaylistName('');
      loadPlaylists();
    } catch (error) {
      toast.error('Failed to create playlist');
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl gradient-purple flex items-center justify-center">
                <ListMusic className="w-5 h-5 text-white" />
              </div>
              Your Playlists
            </h1>
            <p className="text-muted-foreground mt-1">
              Create and manage your music collections
            </p>
          </div>

          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gradient-purple text-white">
                <Plus className="w-4 h-4 mr-2" />
                New Playlist
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Create New Playlist</DialogTitle>
                <DialogDescription>
                  Give your playlist a name
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleCreatePlaylist} className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Name *</label>
                  <Input
                    value={newPlaylistName}
                    onChange={(e) => setNewPlaylistName(e.target.value)}
                    placeholder="My Awesome Playlist"
                    autoFocus
                  />
                </div>
                <Button 
                  type="submit" 
                  className="w-full gradient-purple text-white" 
                  disabled={creating}
                >
                  {creating ? 'Creating...' : 'Create Playlist'}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search and View Toggle */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search playlists..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'outline'}
              size="icon"
              onClick={() => setViewMode('grid')}
            >
              <Grid3X3 className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'outline'}
              size="icon"
              onClick={() => setViewMode('list')}
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Playlists Grid/List */}
        {loading ? (
          viewMode === 'grid' ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="aspect-square rounded-xl bg-muted animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-20 rounded-xl bg-muted animate-pulse" />
              ))}
            </div>
          )
        ) : filteredPlaylists.length > 0 ? (
          viewMode === 'grid' ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {filteredPlaylists.map((playlist) => (
                <PlaylistCard
                  key={playlist.id}
                  playlist={playlist}
                  onClick={() => navigate('playlist-detail', { playlistId: playlist.id })}
                  onDelete={loadPlaylists}
                />
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {filteredPlaylists.map((playlist) => (
                <PlaylistCardCompact
                  key={playlist.id}
                  playlist={playlist}
                  onClick={() => navigate('playlist-detail', { playlistId: playlist.id })}
                  onDelete={loadPlaylists}
                />
              ))}
            </div>
          )
        ) : (
          <div className="text-center py-20">
            <ListMusic className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No playlists yet</h3>
            <p className="text-muted-foreground mb-4">
              {searchQuery ? 'Try a different search term' : 'Create your first playlist to get started'}
            </p>
            {!searchQuery && (
              <Button onClick={() => setDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Create Playlist
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
