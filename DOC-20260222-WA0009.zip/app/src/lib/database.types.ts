// =====================================================
// RaPut4 Music - Database Types
// =====================================================

export interface Database {
  public: {
    Tables: {
      artists: {
        Row: {
          id: string;
          name: string;
          image_url: string | null;
          bio: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          image_url?: string | null;
          bio?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          image_url?: string | null;
          bio?: string | null;
          created_at?: string;
        };
      };
      songs: {
        Row: {
          id: string;
          title: string;
          artist_id: string | null;
          audio_url: string;
          cover_url: string | null;
          lyrics: string | null;
          user_id: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          title: string;
          artist_id?: string | null;
          audio_url: string;
          cover_url?: string | null;
          lyrics?: string | null;
          user_id: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          title?: string;
          artist_id?: string | null;
          audio_url?: string;
          cover_url?: string | null;
          lyrics?: string | null;
          user_id?: string;
          created_at?: string;
        };
      };
      artist_followers: {
        Row: {
          id: string;
          user_id: string;
          artist_id: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          artist_id: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          artist_id?: string;
          created_at?: string;
        };
      };
      liked_songs: {
        Row: {
          id: string;
          user_id: string;
          song_id: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          song_id: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          song_id?: string;
          created_at?: string;
        };
      };
      playlists: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          cover_url: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          name: string;
          cover_url?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          name?: string;
          cover_url?: string | null;
          created_at?: string;
        };
      };
      playlist_songs: {
        Row: {
          id: string;
          playlist_id: string;
          song_id: string;
        };
        Insert: {
          id?: string;
          playlist_id: string;
          song_id: string;
        };
        Update: {
          id?: string;
          playlist_id?: string;
          song_id?: string;
        };
      };
    };
    Functions: {
      get_song_like_count: {
        Args: { song_uuid: string };
        Returns: number;
      };
      user_liked_song: {
        Args: { song_uuid: string; user_uuid: string };
        Returns: boolean;
      };
      get_artist_follower_count: {
        Args: { artist_uuid: string };
        Returns: number;
      };
      user_follows_artist: {
        Args: { artist_uuid: string; user_uuid: string };
        Returns: boolean;
      };
    };
  };
}
