// =====================================================
// RaPut4 Music - Supabase Client
// =====================================================

import { createClient } from '@supabase/supabase-js';
import type { Database } from './database.types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('Supabase credentials not found. Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY environment variables.');
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey);

// Auth helpers
export const signUp = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
  });
  return { data, error };
};

export const signIn = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  return { data, error };
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  return { error };
};

export const getCurrentUser = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
};

export const getSession = async () => {
  const { data: { session } } = await supabase.auth.getSession();
  return session;
};

// Storage helpers
export const uploadAudioFile = async (file: File, userId: string) => {
  const fileExt = file.name.split('.').pop();
  const fileName = `${userId}/${Date.now()}.${fileExt}`;
  
  const { data, error } = await supabase.storage
    .from('audio-files')
    .upload(fileName, file);
  
  if (error) throw error;
  
  const { data: { publicUrl } } = supabase.storage
    .from('audio-files')
    .getPublicUrl(fileName);
  
  return publicUrl;
};

export const uploadCoverImage = async (file: File, userId: string) => {
  const fileExt = file.name.split('.').pop();
  const fileName = `${userId}/${Date.now()}.${fileExt}`;
  
  const { data, error } = await supabase.storage
    .from('cover-images')
    .upload(fileName, file);
  
  if (error) throw error;
  
  const { data: { publicUrl } } = supabase.storage
    .from('cover-images')
    .getPublicUrl(fileName);
  
  return publicUrl;
};

export const uploadArtistImage = async (file: File, userId: string) => {
  const fileExt = file.name.split('.').pop();
  const fileName = `${userId}/${Date.now()}.${fileExt}`;
  
  const { data, error } = await supabase.storage
    .from('artist-images')
    .upload(fileName, file);
  
  if (error) throw error;
  
  const { data: { publicUrl } } = supabase.storage
    .from('artist-images')
    .getPublicUrl(fileName);
  
  return publicUrl;
};

// Database helpers
export const fetchSongs = async () => {
  const { data, error } = await supabase
    .from('songs')
    .select(`
      *,
      artist:artists(*)
    `)
    .order('created_at', { ascending: false });
  
  return { data, error };
};

export const fetchSongById = async (id: string) => {
  const { data, error } = await supabase
    .from('songs')
    .select(`
      *,
      artist:artists(*)
    `)
    .eq('id', id)
    .single();
  
  return { data, error };
};

export const fetchSongsByUser = async (userId: string) => {
  const { data, error } = await supabase
    .from('songs')
    .select(`
      *,
      artist:artists(*)
    `)
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  return { data, error };
};

export const fetchArtists = async () => {
  const { data, error } = await supabase
    .from('artists')
    .select('*')
    .order('name', { ascending: true });
  
  return { data, error };
};

export const fetchArtistById = async (id: string) => {
  const { data, error } = await supabase
    .from('artists')
    .select('*')
    .eq('id', id)
    .single();
  
  return { data, error };
};

export const fetchSongsByArtist = async (artistId: string) => {
  const { data, error } = await supabase
    .from('songs')
    .select(`
      *,
      artist:artists(*)
    `)
    .eq('artist_id', artistId)
    .order('created_at', { ascending: false });
  
  return { data, error };
};

export const fetchPlaylists = async (userId: string) => {
  const { data, error } = await supabase
    .from('playlists')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  return { data, error };
};

export const fetchPlaylistById = async (id: string) => {
  const { data, error } = await supabase
    .from('playlists')
    .select(`
      *,
      playlist_songs(
        *,
        song:songs(*, artist:artists(*))
      )
    `)
    .eq('id', id)
    .single();
  
  return { data, error };
};

export const fetchLikedSongs = async (userId: string) => {
  const { data, error } = await supabase
    .from('liked_songs')
    .select(`
      *,
      song:songs(*, artist:artists(*))
    `)
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  return { data, error };
};

export const likeSong = async (userId: string, songId: string) => {
  const { data, error } = await supabase
    .from('liked_songs')
    .insert({ user_id: userId, song_id: songId })
    .select()
    .single();
  
  return { data, error };
};

export const unlikeSong = async (userId: string, songId: string) => {
  const { error } = await supabase
    .from('liked_songs')
    .delete()
    .eq('user_id', userId)
    .eq('song_id', songId);
  
  return { error };
};

export const followArtist = async (userId: string, artistId: string) => {
  const { data, error } = await supabase
    .from('artist_followers')
    .insert({ user_id: userId, artist_id: artistId })
    .select()
    .single();
  
  return { data, error };
};

export const unfollowArtist = async (userId: string, artistId: string) => {
  const { error } = await supabase
    .from('artist_followers')
    .delete()
    .eq('user_id', userId)
    .eq('artist_id', artistId);
  
  return { error };
};

export const createPlaylist = async (userId: string, name: string, coverUrl: string | null) => {
  const { data, error } = await supabase
    .from('playlists')
    .insert({ user_id: userId, name, cover_url: coverUrl })
    .select()
    .single();
  
  return { data, error };
};

export const addSongToPlaylist = async (playlistId: string, songId: string) => {
  const { data, error } = await supabase
    .from('playlist_songs')
    .insert({ playlist_id: playlistId, song_id: songId })
    .select()
    .single();
  
  return { data, error };
};

export const removeSongFromPlaylist = async (playlistId: string, songId: string) => {
  const { error } = await supabase
    .from('playlist_songs')
    .delete()
    .eq('playlist_id', playlistId)
    .eq('song_id', songId);
  
  return { error };
};

export const deletePlaylist = async (playlistId: string) => {
  const { error } = await supabase
    .from('playlists')
    .delete()
    .eq('id', playlistId);
  
  return { error };
};

export const createSong = async (songData: {
  title: string;
  artist_id: string | null;
  audio_url: string;
  cover_url: string | null;
  lyrics: string | null;
  user_id: string;
}) => {
  const { data, error } = await supabase
    .from('songs')
    .insert(songData)
    .select()
    .single();
  
  return { data, error };
};

export const updateSong = async (songId: string, songData: Partial<{
  title: string;
  artist_id: string | null;
  audio_url: string;
  cover_url: string | null;
  lyrics: string | null;
}>) => {
  const { data, error } = await supabase
    .from('songs')
    .update(songData)
    .eq('id', songId)
    .select()
    .single();
  
  return { data, error };
};

export const deleteSong = async (songId: string) => {
  const { error } = await supabase
    .from('songs')
    .delete()
    .eq('id', songId);
  
  return { error };
};

export const createArtist = async (artistData: {
  name: string;
  image_url: string | null;
  bio: string | null;
}) => {
  const { data, error } = await supabase
    .from('artists')
    .insert(artistData)
    .select()
    .single();
  
  return { data, error };
};
